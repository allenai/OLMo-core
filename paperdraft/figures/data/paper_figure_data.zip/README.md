# Raw data for Figure 1 and the cross-task grid

Two tidy CSVs, one row per plotted point. Regenerate with:

```bash
cd paperdraft/figures && python3 export_figure_data.py
```

The exporter **imports** `fig1_gap_vs_context.py` and `fig4_cross_task.py` rather than
re-typing their numbers, so the CSVs cannot drift from what the paper actually plots. If a
figure script changes, re-run the exporter.

## Which figures these are

| CSV | Script | PDF | Figure number in the current build |
|---|---|---|---|
| `fig1_gap_vs_context_data.csv` | `fig1_gap_vs_context.py` | `fig1_gap_vs_context.pdf` | **Figure 1** (`fig:motivatingtask`) |
| `fig4_cross_task_data.csv` | `fig4_cross_task.py` | `fig4_cross_task.pdf` | **Figure 5** (`fig:sec5-cross-task`) |

⚠ The second file is named `fig4_*` but compiles as **Figure 5**. Figure 4 in the current
PDF is `fig:masks`, the attention-mask schematic (`attention-masks-figure (6).pdf`), which
is a hand-drawn diagram with no underlying data. The cross-task grid is what's exported here.

## Columns common to both files

| Column | Meaning |
|---|---|
| `task` | Task name as it appears in the figure script |
| `ctc_class` | **`low`** or **`high`** corpus-traversal complexity — the orange/green split in Fig 1, the column split in the grid |
| `ctc_order` | Finer class: `O_T(N)` (= low) vs `O_T(NM)` / `O_T(N^2)+` (= high) |
| `metric` | Per-task metric from Table 1 (`table_suite.tex`) |
| `context_tokens` | Context length in tokens — the x-axis of Fig 1 |
| `n_docs` | Corpus size $N$ where the run was denominated in documents |
| `full_attention` | Score of the full-attention arm |
| `chunked_attention` | Score of the document-chunked + mask-mixing arm (best-case chunked) |
| `relative_gap` | `1 - chunked/full`, the y-axis of Fig 1. Blank where undefined (missing arm, or a zero full arm) |
| `eval_size` | Number of eval examples. `unknown (see README)` where neither figure script states it |

Both arms are Qwen3.5-4B unless noted below.

### `fig1_gap_vs_context_data.csv` (76 rows)

Extra columns:

- `series` — `background` (thin grey-alpha lines) vs `highlighted (star line)` (HotpotQA,
  Contradiction, drawn as bold star lines).
- `source` — `CTC suite (token ladder)`: the 2k/4k/8k/16k/32k budget rungs. `per_N runs`:
  the earlier per-$N$ sweeps, put on the token axis as $N \times$ per-doc tokens.
- `plotted_in_figure` / `drop_reason` — Figure 1 drops any rung whose **full** arm is under
  `FLOOR = 0.15`, because a ratio between two near-zero numbers is noise. Those rows are kept
  in the CSV with `plotted_in_figure=no` so the exclusion is visible rather than silent.
  8 of 76 rows are dropped this way: `mathmatch` entirely (3), `textgroups` down to a single
  point at 2k (4), and `reorder`'s 16k rung (1).

⚠ The `per_N` rows are **not the same runs as the suite rows**, and HotpotQA is not even the
same model (Qwen3.5-0.8B LoRA, vs 4B full fine-tune everywhere else). The figure script's
docstring explains why each was sourced that way — read it before re-plotting these together.

### `fig4_cross_task_data.csv` (77 rows)

Extra columns:

- `panel` — which of the 9 panels the row belongs to. `panel_y_label` is the axis label that
  panel actually prints, which is coarser than `metric` (the cross-document panel puts four
  different metrics on one axis).
- `x_axis` — `tokens` for the suite ladders, `documents` for the four kept per-$N$ panels.
- `context_tokens_exact` — `yes` for token-ladder rows. `no (N x per-doc tokens)` means the
  context length is **derived**: $N \times$ the per-doc token estimate from Table 5
  (contradiction ~45 tok/doc, grouping ~200, outlier-wiki / reorder ~130). Use `n_docs` if
  you want the number the run was actually parameterized by.
- `variant` — outlier's `scale-k` vs `fixed-k` ablation (solid vs dashed in the figure), and
  the single `chunked, NO mask mixing` X point on reorder.
- `notes` — currently only marks that X point, which has no matching full-attention run.

Reorder is Qwen3.5-9B; every other panel is 4B.

Blank `full_attention` / `chunked_attention` means **that run does not exist**, not zero.

## Caveats worth passing on

- **eval_size below 500.** OBLIQ is 126 per rung (SE ±0.045) and contradiction is 488 (the
  entire held-out file). Anything quoted off those two needs its error bar inline.
- **`unknown` eval sizes.** The per-$N$ ladders aren't covered by the figure scripts'
  "500 per rung" statement, so they're exported as unknown rather than assumed. Appendix
  Table 6 flags outlier-wiki at 56–100 examples per rung, and its own Table 5 says 400 for
  the same rows — that disagreement is noted in the appendix and is still unresolved.
- **`absence` is classified `low` / `O_T(N)` here**, following Prasann's 2026-08-03
  correction that both figure scripts implement. Table 1 (`table_suite.tex`) still lists it
  under the $O_T(N^2)$ block and is stale on this point. `xabsence` is the genuinely
  $O_T(N^2)$ one.
- **Metric naming.** The panel labels in the grid call NIAH / MS MARCO / OBLIQ "gold-ID F1"
  where Table 1 calls them set-F1. The `metric` column follows Table 1; `panel_y_label`
  preserves what the figure prints.
- **Sign convention.** A negative `relative_gap` means chunked *beat* full at that rung
  (real, e.g. NQ and GovReport). Don't clip it to zero.
- Each figure script's module docstring lists every task that was **excluded** and why
  (broken checkpoints, floor-level scores, voided ladders). Those reasons are not in the
  CSVs — read the docstrings before adding a task back.
